"""هستهٔ MyVPN برای ویندوز: تجزیهٔ لینک، مدیریت Xray، پروکسی سیستم، پینگ، سرور رایگان."""
import base64, json, os, random, socket, subprocess, sys, threading, time, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor

try:
    import winreg, ctypes
except ImportError:          # برای تست روی سیستم‌های غیر ویندوز
    winreg = None

HTTP_PORT = 10809
PROBE_URL = "http://www.gstatic.com/generate_204"
POOL_SIZE = 3
FREE_SOURCES = [
    "https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt",
    "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/All_Configs_Sub.txt",
    "https://raw.githubusercontent.com/MatinGhanbari/v2ray-CONFIGs/main/subscriptions/v2ray/super-sub.txt",
    "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge.txt",
]
NO_WINDOW = 0x08000000 if os.name == "nt" else 0


def res(path):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, path)


def xray_path():
    p = res("xray.exe")
    return p if os.path.exists(p) else "xray"


# ---------------------------------------------------------------- تجزیهٔ لینک
class Server:
    def __init__(self, name, link, outbound):
        self.name, self.link, self.outbound = name, link, outbound
        self.ping = -1       # -1 تست نشده، 0 در حال تست، >0 میلی‌ثانیه، -2 ناموفق
        self.free = False


def b64(s):
    t = s.strip().replace("-", "+").replace("_", "/")
    t += "=" * (-len(t) % 4)
    return base64.b64decode(t)


def _stream(typ, sec, sni, fp, host, path, pbk, sid, alpn, svc, spx):
    s = {"network": "h2" if typ == "http" else typ, "security": sec}
    if sec == "tls":
        t = {}
        if sni: t["serverName"] = sni
        if fp: t["fingerprint"] = fp
        if alpn: t["alpn"] = alpn.split(",")
        s["tlsSettings"] = t
    elif sec == "reality":
        s["realitySettings"] = {"serverName": sni or "", "fingerprint": fp or "chrome",
                                "publicKey": pbk or "", "shortId": sid or "", "spiderX": spx or ""}
    if typ == "ws":
        w = {"path": path or "/"}
        if host: w["headers"] = {"Host": host}
        s["wsSettings"] = w
    elif typ == "grpc":
        s["grpcSettings"] = {"serviceName": svc or ""}
    elif typ == "httpupgrade":
        w = {"path": path or "/"}
        if host: w["host"] = host
        s["httpupgradeSettings"] = w
    elif typ in ("xhttp", "splithttp"):
        w = {"path": path or "/"}
        if host: w["host"] = host
        s["xhttpSettings"] = w
    return s


def _url_server(link, proto):
    u = urllib.parse.urlsplit(link)
    q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
    name = urllib.parse.unquote(u.fragment) or f"{u.hostname}:{u.port}"
    ss = _stream(q.get("type", "tcp"), q.get("security", "none" if proto == "vless" else "tls"),
                 q.get("sni"), q.get("fp"), q.get("host"), q.get("path"), q.get("pbk"),
                 q.get("sid"), q.get("alpn"), q.get("serviceName"), q.get("spx"))
    uid = urllib.parse.unquote(u.username or "")
    if proto == "vless":
        user = {"id": uid, "encryption": q.get("encryption", "none")}
        if q.get("flow"): user["flow"] = q["flow"]
        st = {"vnext": [{"address": u.hostname, "port": u.port, "users": [user]}]}
    else:
        st = {"servers": [{"address": u.hostname, "port": u.port, "password": uid}]}
    return Server(name, link, {"tag": "proxy", "protocol": proto, "settings": st, "streamSettings": ss})


def _vmess(link):
    j = json.loads(b64(link[len("vmess://"):]).decode())
    tls = j.get("tls", "")
    ss = _stream(j.get("net", "tcp"), "tls" if tls == "tls" else "none", j.get("sni") or j.get("host"),
                 j.get("fp"), j.get("host"), j.get("path"), None, None, j.get("alpn"), j.get("path"), None)
    out = {"tag": "proxy", "protocol": "vmess", "streamSettings": ss, "settings": {"vnext": [{
        "address": j["add"], "port": int(j["port"]),
        "users": [{"id": j["id"], "alterId": int(j.get("aid", 0) or 0), "security": j.get("scy", "auto")}]}]}}
    return Server(j.get("ps") or j["add"], link, out)


def _ss(link):
    rest = link[len("ss://"):]
    name = urllib.parse.unquote(rest.split("#", 1)[1]) if "#" in rest else ""
    main = rest.split("#")[0].split("?")[0]
    if "@" in main:
        cred, hp = main.split("@", 1)
        try: dec = b64(cred).decode()
        except Exception: dec = cred
        method, pw = dec.split(":", 1)
        host, port = hp.rsplit(":", 1)
    else:
        dec = b64(main).decode()
        method, rest2 = dec.split(":", 1)
        pw, hp = rest2.rsplit("@", 1)
        host, port = hp.rsplit(":", 1)
    out = {"tag": "proxy", "protocol": "shadowsocks",
           "settings": {"servers": [{"address": host, "port": int(port), "method": method, "password": pw}]}}
    return Server(name or f"{host}:{port}", link, out)


def parse(link):
    link = link.strip()
    try:
        if link.startswith("vless://"): return _url_server(link, "vless")
        if link.startswith("trojan://"): return _url_server(link, "trojan")
        if link.startswith("vmess://"): return _vmess(link)
        if link.startswith("ss://"): return _ss(link)
    except Exception:
        return None
    return None


def parse_many(text):
    body = text.strip()
    if "://" not in body:
        try: body = b64(body).decode()
        except Exception: pass
    out = []
    for ln in body.splitlines():
        s = parse(ln)
        if s: out.append(s)
    return out


# ---------------------------------------------------------------- کانفیگ Xray
def full_config(pool, dns):
    outs = []
    for i, s in enumerate(pool):
        o = json.loads(json.dumps(s.outbound)); o["tag"] = f"proxy-{i}"; outs.append(o)
    outs.append({"tag": "direct", "protocol": "freedom"})
    return {
        "log": {"loglevel": "warning"},
        "dns": {"servers": dns},
        "inbounds": [
            {"tag": "http-in", "listen": "127.0.0.1", "port": HTTP_PORT, "protocol": "http",
             "sniffing": {"enabled": True, "destOverride": ["http", "tls"]}},
            {"tag": "socks-in", "listen": "127.0.0.1", "port": HTTP_PORT - 1, "protocol": "socks",
             "settings": {"udp": True},
             "sniffing": {"enabled": True, "destOverride": ["http", "tls"]}}],
        "outbounds": outs,
        "observatory": {"subjectSelector": ["proxy-"], "probeUrl": "https://www.gstatic.com/generate_204",
                        "probeInterval": "10s"},
        "routing": {"domainStrategy": "AsIs", "rules": [
            {"type": "field", "ip": ["10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8"],
             "outboundTag": "direct"},
            {"type": "field", "network": "tcp,udp", "balancerTag": "bal"}],
            "balancers": [{"tag": "bal", "selector": ["proxy-"], "strategy": {"type": "leastPing"},
                           "fallbackTag": "proxy-0"}]},
    }


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def measure(server, timeout=6.0):
    """پینگ واقعی: یک Xray موقت + درخواست generate_204 از میان آن. میلی‌ثانیه یا -2."""
    port = free_port()
    cfg = {"log": {"loglevel": "none"},
           "inbounds": [{"listen": "127.0.0.1", "port": port, "protocol": "http"}],
           "outbounds": [server.outbound]}
    proc = subprocess.Popen([xray_path(), "run", "-config", "stdin:"], stdin=subprocess.PIPE,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
    try:
        proc.stdin.write(json.dumps(cfg).encode()); proc.stdin.close()
        t0 = time.time()
        while time.time() - t0 < 3:
            try: socket.create_connection(("127.0.0.1", port), 0.2).close(); break
            except OSError: time.sleep(0.1)
        else:
            return -2
        op = urllib.request.build_opener(urllib.request.ProxyHandler({"http": f"http://127.0.0.1:{port}"}))
        t1 = time.time()
        r = op.open(PROBE_URL, timeout=timeout); r.read()
        return max(1, int((time.time() - t1) * 1000))
    except Exception:
        return -2
    finally:
        try: proc.kill()
        except Exception: pass


def test_all(servers, concurrency=8, each=None):
    for s in servers: s.ping = 0
    def one(s):
        s.ping = measure(s)
        if each: each(s)
    with ThreadPoolExecutor(concurrency) as ex: list(ex.map(one, servers))


# ---------------------------------------------------------------- پروکسی سیستم
def _refresh_proxy():
    if os.name == "nt":
        w = ctypes.windll.Wininet
        w.InternetSetOptionW(0, 39, 0, 0); w.InternetSetOptionW(0, 37, 0, 0)


def set_system_proxy(on):
    if winreg is None: return
    k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                       0, winreg.KEY_SET_VALUE)
    winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 1 if on else 0)
    if on:
        winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, f"127.0.0.1:{HTTP_PORT}")
        winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, "<local>;localhost;127.*;10.*;172.16.*;192.168.*")
    winreg.CloseKey(k); _refresh_proxy()


# ---------------------------------------------------------------- ذخیره
class Store:
    DEF = {"links": [], "free": [], "dns": ["1.1.1.1", "8.8.8.8"], "want": False}

    def __init__(self):
        d = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "MyVPN")
        os.makedirs(d, exist_ok=True)
        self.f = os.path.join(d, "store.json")
        try: self.d = {**self.DEF, **json.load(open(self.f, encoding="utf-8"))}
        except Exception: self.d = dict(self.DEF)

    def save(self):
        json.dump(self.d, open(self.f, "w", encoding="utf-8"), ensure_ascii=False)

    def servers(self):
        out = {}
        for l in self.d["links"]:
            s = parse(l)
            if s: out[l] = s
        for l in self.d["free"]:
            s = parse(l)
            if s and l not in out: s.free = True; out[l] = s
        return list(out.values())


# ---------------------------------------------------------------- منطق اصلی
class Engine:
    def __init__(self):
        self.store = Store()
        self.servers = self.store.servers()
        self.phase = "idle"          # idle | connecting | connected
        self.status = "قطع"
        self.proc = None
        self.active = ""
        self.busy = False
        self.stop_flag = threading.Event()
        self.lock = threading.RLock()
        set_system_proxy(False)      # پروکسیِ مانده از اجرای قبلی (کرش) پاک شود

    # --- لیست
    def reload(self):
        old = {s.link: s for s in self.servers}
        self.servers = self.store.servers()
        for s in self.servers:
            if s.link in old: s.ping = old[s.link].ping

    def add(self, text):
        if text.strip().startswith("http"):
            try: text = urllib.request.urlopen(text.strip(), timeout=15).read().decode("utf-8", "ignore")
            except Exception: self.status = "دریافت اشتراک ناموفق بود"; return 0
        parsed = parse_many(text)
        if not parsed: self.status = "لینک معتبری پیدا نشد"; return 0
        links = self.store.d["links"]
        for s in parsed:
            if s.link not in links: links.append(s.link)
        self.store.save(); self.reload()
        self.status = f"{len(parsed)} سرور اضافه شد"
        threading.Thread(target=self.ping_all, daemon=True).start()
        return len(parsed)

    def clear(self):
        self.store.d["links"] = []; self.store.d["free"] = []; self.store.save(); self.reload()

    def ping_all(self):
        if self.busy: return
        self.busy = True
        try:
            self.status = "در حال تست پینگ…"
            test_all(self.servers)
            ok = sorted([s for s in self.servers if s.ping > 0], key=lambda s: s.ping)
            self.status = f"بهترین: {ok[0].name} ({ok[0].ping} ms)" if ok else "هیچ سروری پاسخ نداد"
        finally:
            self.busy = False

    def find_free(self):
        if self.busy: return
        self.busy = True
        try:
            found = {}
            for i, src in enumerate(FREE_SOURCES):
                self.status = f"دریافت لیست {i + 1}/{len(FREE_SOURCES)}…"
                try: text = urllib.request.urlopen(src, timeout=20).read(6_000_000).decode("utf-8", "ignore")
                except Exception: continue
                ps = parse_many(text); random.shuffle(ps)
                for s in ps[:400]: found.setdefault(s.link, s)
            if not found:
                self.status = "دریافت لیست رایگان ناموفق بود (اینترنت/دسترسی به GitHub)"; return
            cand = random.sample(list(found.values()), min(100, len(found)))
            self.status = f"تست پینگ {len(cand)} سرور…"
            test_all(cand, 12)
            good = sorted([s for s in cand if s.ping > 0], key=lambda s: s.ping)[:15]
            if good:
                self.store.d["free"] = [s.link for s in good]; self.store.save(); self.reload()
                for g in good:
                    for s in self.servers:
                        if s.link == g.link: s.ping = g.ping
            self.status = f"{len(good)} سرور رایگان سالم پیدا شد"
        finally:
            self.busy = False

    # --- اتصال
    def connect(self, link=None):
        with self.lock:
            if self.phase == "connecting": return
            self.phase = "connecting"; self.status = "در حال اتصال…"
        threading.Thread(target=self._connect, args=(link,), daemon=True).start()

    def _connect(self, link):
        try:
            self._stop_proc(); set_system_proxy(False)
            self.reload()
            if not self.servers:
                self.status = "سروری نیست؛ ابتدا سرور اضافه کنید"; self.phase = "idle"; return
            if link:
                first = next((s for s in self.servers if s.link == link), None)
                cand = [first] if first else []
            else:
                cand = list(self.servers)
                random.shuffle(cand); cand = cand[:40]
            self.status = "در حال یافتن بهترین سرور…"
            test_all(cand, 8)
            good = sorted([s for s in cand if s.ping > 0], key=lambda s: s.ping)
            if not good:
                self.status = "هیچ سروری پاسخ نداد"; self.phase = "idle"; return
            pool = good[:POOL_SIZE]
            if link is None:
                pass
            self._start_xray(pool)
            ok = False
            for _ in range(15):
                time.sleep(0.4)
                if self._alive() and self._probe(): ok = True; break
            if not ok:
                self._stop_proc(); self.status = "اتصال برقرار نشد"; self.phase = "idle"; return
            set_system_proxy(True)
            self.active = pool[0].name
            self.phase = "connected"; self.status = f"وصل شد · {pool[0].name} ({pool[0].ping} ms)"
            self.store.d["want"] = True; self.store.save()
            self.stop_flag.clear()
            threading.Thread(target=self._watch, args=(pool,), daemon=True).start()
        except Exception as e:
            self.status = f"خطا: {e}"; self.phase = "idle"

    def _start_xray(self, pool):
        cfg = json.dumps(full_config(pool, self.store.d["dns"])).encode()
        self.proc = subprocess.Popen([xray_path(), "run", "-config", "stdin:"], stdin=subprocess.PIPE,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
        self.proc.stdin.write(cfg); self.proc.stdin.close()

    def _alive(self):
        return self.proc is not None and self.proc.poll() is None

    def _probe(self, timeout=6):
        try:
            op = urllib.request.build_opener(urllib.request.ProxyHandler({"http": f"http://127.0.0.1:{HTTP_PORT}"}))
            op.open(PROBE_URL, timeout=timeout).read(); return True
        except Exception:
            return False

    def _watch(self, pool):
        fails = 0
        while not self.stop_flag.wait(15):
            if self.phase != "connected": return
            if not self._alive():
                self.status = "Xray متوقف شد؛ راه‌اندازی دوباره…"
                try: self._start_xray(pool); time.sleep(1.5)
                except Exception: pass
                continue
            if self._probe(): fails = 0
            else:
                fails += 1
                if fails >= 2:           # دو بار پشت‌سرهم قطع: انتخاب مجدد بهترین‌ها
                    self.status = "ضعیف شد؛ جستجوی سرور بهتر…"
                    self.stop_flag.set()
                    self.phase = "idle"; self.connect(None); return

    def _stop_proc(self):
        if self.proc is not None:
            try: self.proc.kill()
            except Exception: pass
            self.proc = None

    def disconnect(self):
        self.stop_flag.set()
        self.store.d["want"] = False; self.store.save()
        self._stop_proc(); set_system_proxy(False)
        self.phase = "idle"; self.status = "قطع"

    # --- وضعیت برای رابط
    def state(self):
        order = sorted(self.servers, key=lambda s: (s.ping <= 0 and s.ping != 0, s.ping if s.ping > 0 else 10**9))
        return {"phase": self.phase, "status": self.status, "busy": self.busy, "dns": self.store.d["dns"],
                "servers": [{"name": s.name, "link": s.link, "ping": s.ping, "free": s.free} for s in order]}
