import os, sys, threading, webview
import core


class Api:
    def __init__(self):
        self.e = core.Engine()

    def state(self): return self.e.state()
    def add(self, text): threading.Thread(target=self.e.add, args=(text,), daemon=True).start()
    def clear(self): self.e.clear()
    def ping_all(self): threading.Thread(target=self.e.ping_all, daemon=True).start()
    def find_free(self): threading.Thread(target=self.e.find_free, daemon=True).start()
    def connect(self, link=None): self.e.connect(link or None)
    def disconnect(self): self.e.disconnect()
    def set_dns(self, text):
        items = [x.strip() for x in text.replace("،", ",").replace("\n", ",").split(",") if x.strip()]
        if items:
            self.e.store.d["dns"] = items; self.e.store.save()
        return self.e.store.d["dns"]


def main():
    api = Api()
    win = webview.create_window("MyVPN", core.res(os.path.join("ui", "index.html")), js_api=api,
                                width=440, height=860, min_size=(400, 700))
    win.events.closed += lambda: api.e.disconnect()
    if api.e.store.d.get("want"):
        threading.Timer(1.5, lambda: api.e.connect(None)).start()
    webview.start()
    api.e.disconnect()


if __name__ == "__main__":
    main()
